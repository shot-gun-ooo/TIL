
use tutorial;
db.users.insertOne({ username: "smith" });
db.users.insertOne({ username: "jones" });
db.users.find();
db.users.findOne();


db.users.find({ username: "jones" });
db.users.find({ username: { $in: ["jones", "smith"] } });


db.users.updateOne({ username: "smith" }, { $set: { country: "Canada" } });
db.users.find({ username: "smith" });


db.users.replaceOne({ username: "smith" }, { country: "Canada" });
db.users.find({ country: "Canada" });
db.users.replaceOne({ country: "Canada" }, { username: "smith", country: "Canada" });
db.users.find({ username: "smith" });


db.users.updateOne({ username: "smith" }, { $unset: { country: "" } });
db.users.find({ username: "smith" });


show dbs;
show collections;
db.stats();
db.users.stats();


db.users.deleteOne({ username: "smith" });
db.users.deleteMany({});
db.users.drop();



use test;
var docs = []; 
for (var i = 0; i < 20000; i++) { 
    docs.push({ num: i, name: '스마트폰 ' + i }); 
} 
db.product.insertMany(docs);
db.product.countDocuments();


db.product.find().sort({ num: -1 });
db.product.find().sort({ num: -1 }).limit(10);
db.product.find().sort({ num: -1 }).skip(50).limit(10);


db.product.find({ $or: [ { num: { $lt: 15 } }, { num: { $gt: 19995 } } ] });
db.product.find({ name: { $in: ['스마트폰 10', '스마트폰 100', '스마트폰 1000'] } });


db.product.find({ num: { $lt: 5 } }, { name: 1, _id: 0 });
